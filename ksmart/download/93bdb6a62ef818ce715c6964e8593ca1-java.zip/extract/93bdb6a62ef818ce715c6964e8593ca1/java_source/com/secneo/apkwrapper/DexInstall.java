/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  dalvik.system.DexFile
 */
package com.secneo.apkwrapper;

import android.os.Build;
import dalvik.system.DexFile;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.zip.ZipFile;

public class DexInstall {
    private static void expandFieldArray(Object object, String object2, Object[] arrobject) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        object2 = DexInstall.findField(object, (String)object2);
        Object[] arrobject2 = (Object[])object2.get(object);
        Object[] arrobject3 = (Object[])Array.newInstance(arrobject2.getClass().getComponentType(), arrobject2.length + arrobject.length);
        System.arraycopy(arrobject2, 0, arrobject3, arrobject.length, arrobject2.length);
        System.arraycopy(arrobject, 0, arrobject3, 0, arrobject.length);
        object2.set(object, arrobject3);
    }

    private static Field findField(Object object, String string2) throws NoSuchFieldException {
        for (Class class_ = object.getClass(); class_ != null; class_ = class_.getSuperclass()) {
            try {
                Field field = class_.getDeclaredField(string2);
                if (!field.isAccessible()) {
                    field.setAccessible(true);
                }
                return field;
            }
            catch (NoSuchFieldException noSuchFieldException) {
                continue;
            }
        }
        throw new NoSuchFieldException("Field " + string2 + " not found in " + object.getClass());
    }

    private static /* varargs */ Method findMethod(Object object, String string2, Class<?> ... arrclass) throws NoSuchMethodException {
        for (Class class_ = object.getClass(); class_ != null; class_ = class_.getSuperclass()) {
            try {
                Method method = class_.getDeclaredMethod(string2, arrclass);
                if (!method.isAccessible()) {
                    method.setAccessible(true);
                }
                return method;
            }
            catch (NoSuchMethodException noSuchMethodException) {
                continue;
            }
        }
        throw new NoSuchMethodException("Method " + string2 + " with parameters " + Arrays.asList(arrclass) + " not found in " + object.getClass());
    }

    public static void install(ClassLoader classLoader, String object) {
        try {
            object = new File((String)object);
            ArrayList<File> arrayList = new ArrayList<File>();
            arrayList.add((File)object);
            DexInstall.installSecondaryDexes(classLoader, object.getParentFile(), arrayList);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace(System.out);
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void installSecondaryDexes(ClassLoader classLoader, File file, List<File> list) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException, IOException {
        if (list.isEmpty()) return;
        if (Build.VERSION.SDK_INT >= 19) {
            V19.install(classLoader, list, file);
            return;
        }
        if (Build.VERSION.SDK_INT >= 14) {
            V14.install(classLoader, list, file);
            return;
        }
        V4.install(classLoader, list);
    }

    private static final class V14 {
        private V14() {
        }

        private static void install(ClassLoader object, List<File> list, File file) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException {
            object = DexInstall.findField(object, "pathList").get(object);
            DexInstall.expandFieldArray(object, "dexElements", V14.makeDexElements(object, new ArrayList<File>(list), file));
        }

        private static Object[] makeDexElements(Object object, ArrayList<File> arrayList, File file) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
            return (Object[])DexInstall.findMethod(object, "makeDexElements", new Class[]{ArrayList.class, File.class}).invoke(object, arrayList, file);
        }
    }

    private static final class V19 {
        private V19() {
        }

        /*
         * Enabled aggressive block sorting
         */
        private static void install(ClassLoader classLoader, List<File> arriOException, File object) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException {
            IOException[] arriOException2 = DexInstall.findField(classLoader, "pathList").get(classLoader);
            ArrayList<IOException> arrayList = new ArrayList<IOException>();
            DexInstall.expandFieldArray(arriOException2, "dexElements", V19.makeDexElements(arriOException2, new ArrayList<File>((Collection<File>)arriOException), (File)object, arrayList));
            if (arrayList.size() > 0) {
                arriOException = arrayList.iterator();
                while (arriOException.hasNext()) {
                    ((IOException)arriOException.next()).printStackTrace(System.out);
                }
                object = DexInstall.findField(classLoader, "dexElementsSuppressedExceptions");
                arriOException2 = (IOException[])object.get(classLoader);
                if (arriOException2 == null) {
                    arriOException = arrayList.toArray(new IOException[arrayList.size()]);
                } else {
                    arriOException = new IOException[arrayList.size() + arriOException2.length];
                    arrayList.toArray(arriOException);
                    System.arraycopy(arriOException2, 0, arriOException, arrayList.size(), arriOException2.length);
                }
                object.set(classLoader, arriOException);
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private static Object[] makeDexElements(Object object, ArrayList<File> arrayList, File file, ArrayList<IOException> arrayList2) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
            Method method;
            Method method2;
            method = null;
            try {
                method = method2 = DexInstall.findMethod(object, "makeDexElements", new Class[]{ArrayList.class, File.class, ArrayList.class});
            }
            catch (Exception exception) {}
            method2 = method;
            if (method != null) return (Object[])method2.invoke(object, arrayList, file, arrayList2);
            {
                try {
                    method2 = DexInstall.findMethod(object, "makePathElements", new Class[]{List.class, File.class, List.class});
                    return (Object[])method2.invoke(object, arrayList, file, arrayList2);
                }
                catch (Exception exception) {
                    method2 = method;
                }
            }
            return (Object[])method2.invoke(object, arrayList, file, arrayList2);
        }
    }

    private static final class V4 {
        private V4() {
        }

        private static void install(ClassLoader classLoader, List<File> object) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, IOException {
            int n = object.size();
            Field field = DexInstall.findField(classLoader, "path");
            StringBuilder stringBuilder = new StringBuilder((String)field.get(classLoader));
            Object[] arrobject = new String[n];
            Object[] arrobject2 = new File[n];
            Object[] arrobject3 = new ZipFile[n];
            Object[] arrobject4 = new DexFile[n];
            object = object.listIterator();
            while (object.hasNext()) {
                File file = (File)object.next();
                String string2 = file.getAbsolutePath();
                stringBuilder.append(':').append(string2);
                n = object.previousIndex();
                arrobject[n] = string2;
                arrobject2[n] = file;
                arrobject3[n] = new ZipFile(file);
                arrobject4[n] = DexFile.loadDex((String)string2, (String)(string2 + ".dex"), (int)0);
            }
            field.set(classLoader, stringBuilder.toString());
            DexInstall.expandFieldArray(classLoader, "mPaths", arrobject);
            DexInstall.expandFieldArray(classLoader, "mFiles", arrobject2);
            DexInstall.expandFieldArray(classLoader, "mZips", arrobject3);
            DexInstall.expandFieldArray(classLoader, "mDexs", arrobject4);
        }
    }

}

