/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Build
 *  android.util.ArrayMap
 *  android.view.LayoutInflater
 */
package com.secneo.apkwrapper;

import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.util.ArrayMap;
import android.view.LayoutInflater;
import com.secneo.apkwrapper.FilesFileObserver;
import com.secneo.apkwrapper.Helper;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ApplicationWrapper
extends Application {
    public static Application realApplication = null;

    static {
        FilesFileObserver.miui_notify();
        System.loadLibrary("DexHelper");
        if (Helper.PPATH != null) {
            System.load(Helper.PPATH);
        }
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        try {
            realApplication = (Application)this.getClassLoader().loadClass(Helper.APPNAME).newInstance();
            Helper.attach(realApplication, context);
            return;
        }
        catch (Exception exception) {
            realApplication = null;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void huawei_share() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
        if (Build.BRAND.equalsIgnoreCase("Huawei") || Build.BRAND.equalsIgnoreCase("Honor")) {
            Iterator iterator = Class.forName("android.app.ActivityThread");
            Object object = iterator.getDeclaredMethod("currentActivityThread", new Class[0]).invoke(iterator, new Object[0]);
            iterator = iterator.getDeclaredMethod("getSystemContext", new Class[0]).invoke(object, new Object[0]);
            object = Class.forName("android.app.ContextImpl").getDeclaredField("sSharedPrefs");
            object.setAccessible(true);
            if (!(iterator = object.get(iterator)).getClass().toString().contains("HashMap") && iterator != null && !"{}".endsWith(iterator.toString())) {
                iterator = ((ArrayMap)((ArrayMap)iterator).get((Object)Helper.PKGNAME)).entrySet().iterator();
                while (iterator.hasNext()) {
                    object = (Map.Entry)iterator.next();
                    object.getKey();
                    object = object.getValue();
                    Class class_ = object.getClass();
                    Field field = class_.getDeclaredField("mMode");
                    field.setAccessible(true);
                    field.get(object);
                    class_ = class_.getDeclaredMethod("startLoadFromDisk", new Class[0]);
                    class_.setAccessible(true);
                    class_.invoke(object, new Object[0]);
                }
            }
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (realApplication != null) {
            realApplication.onConfigurationChanged(configuration);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void onCreate() {
        super.onCreate();
        try {
            this.huawei_share();
        }
        catch (Exception exception) {}
        if (realApplication == null) return;
        Helper.attach(realApplication, null);
        realApplication.onCreate();
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.getApplicationContext());
        try {
            Field field = LayoutInflater.class.getDeclaredField("mContext");
            field.setAccessible(true);
            field.set((Object)layoutInflater, (Object)realApplication);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public void onLowMemory() {
        super.onLowMemory();
        if (realApplication != null) {
            realApplication.onLowMemory();
        }
    }

    public void onTerminate() {
        super.onTerminate();
        if (realApplication != null) {
            realApplication.onTerminate();
        }
    }

    public void onTrimMemory(int n) {
        try {
            super.onTrimMemory(n);
            if (realApplication != null) {
                realApplication.onTrimMemory(n);
            }
            return;
        }
        catch (Exception exception) {
            return;
        }
    }
}

