/*
 * Decompiled with CFR 0_119.
 */
package com.secneo.apkwrapper;

public final class BuildConfig {
    public static final boolean DEBUG = false;
}

