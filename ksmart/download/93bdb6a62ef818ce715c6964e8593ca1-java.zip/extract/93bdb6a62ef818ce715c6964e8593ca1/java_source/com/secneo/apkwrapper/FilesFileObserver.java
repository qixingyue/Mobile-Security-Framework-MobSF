/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.os.FileObserver
 *  android.os.Process
 */
package com.secneo.apkwrapper;

import android.os.FileObserver;
import android.os.Process;
import com.secneo.apkwrapper.Helper;
import java.io.File;
import java.io.IOException;

public class FilesFileObserver
extends FileObserver {
    private static boolean flag;
    private static Object object;
    private static FilesFileObserver sPasswordObserver;

    static {
        object = new Object();
        flag = true;
    }

    public FilesFileObserver(String string2, int n) {
        super(string2, n);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void miui_notify() {
        boolean bl = false;
        Object object = new Thread[20];
        int n = Thread.currentThread().getThreadGroup().enumerate((Thread[])object);
        for (int i = 0; i < n; ++i) {
            if (!"FileObserver".equals(object[i].getName())) continue;
            bl = true;
        }
        if (!bl) {
            return;
        }
        new File("/data/data/" + Helper.PKGNAME + "/com.secneo.tmp" + Process.myPid()).delete();
        sPasswordObserver = new FilesFileObserver("/data/data/" + Helper.PKGNAME, 256);
        sPasswordObserver.startWatching();
        try {
            new File("/data/data/" + Helper.PKGNAME + "/com.secneo.tmp" + Process.myPid()).createNewFile();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        object = FilesFileObserver.object;
        synchronized (object) {
            try {
                if (flag) {
                    FilesFileObserver.object.wait(1000);
                }
            }
            catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
        }
        new File("/data/data/" + Helper.PKGNAME + "/com.secneo.tmp" + Process.myPid()).delete();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onEvent(int n, String object) {
        this.stopWatching();
        object = FilesFileObserver.object;
        synchronized (object) {
            flag = false;
            FilesFileObserver.object.notify();
        }
        try {
            Thread.sleep(3000);
            return;
        }
        catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
            return;
        }
    }
}

