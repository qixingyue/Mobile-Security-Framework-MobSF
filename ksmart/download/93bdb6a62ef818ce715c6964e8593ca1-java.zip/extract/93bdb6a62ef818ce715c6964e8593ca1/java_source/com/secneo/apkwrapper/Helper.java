/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 */
package com.secneo.apkwrapper;

import android.app.Application;
import android.content.Context;

public class Helper {
    public static String APPNAME;
    public static String JNIPPATH;
    public static String PKGNAME;
    public static String PPATH;
    public static ClassLoader cl;

    static {
        PPATH = null;
        JNIPPATH = null;
        PKGNAME = "com.hundsun.stockwinner.sxzq";
        APPNAME = "com.hundsun.winner.application.base.WinnerApplication";
    }

    public static native void attach(Application var0, Context var1);

    public static void stub() {
    }
}

