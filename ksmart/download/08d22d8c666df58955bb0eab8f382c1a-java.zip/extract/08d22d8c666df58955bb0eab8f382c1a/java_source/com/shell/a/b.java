/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.ApplicationInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 */
package com.shell.a;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.util.Log;
import com.shell.NativeApplication;
import com.shell.a.d;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

final class b {
    private static final int BUFFER_SIZE = 16384;
    private static final String DEX_PREFIX = "assets/ijiami";
    private static final String DEX_SUFFIX = ".dat";
    private static final String EXTRACTED_NAME_EXT = ".classes";
    private static final String EXTRACTED_SUFFIX = ".zip";
    private static final String KEY_CRC = "crc";
    private static final String KEY_DEX_NUMBER = "dex.number";
    private static final String KEY_TIME_STAMP = "timestamp";
    private static final int MAX_EXTRACT_ATTEMPTS = 3;
    private static final long NO_VALUE = -1;
    private static final String PREFS_FILE = "multidex.sp";
    private static final String TAG = "MultiDex";
    private static Method sApplyMethod;

    static {
        try {
            sApplyMethod = SharedPreferences.Editor.class.getMethod("apply", new Class[0]);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            sApplyMethod = null;
        }
    }

    b() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void apply(SharedPreferences.Editor editor) {
        if (sApplyMethod != null) {
            try {
                sApplyMethod.invoke((Object)editor, new Object[0]);
                return;
            }
            catch (IllegalAccessException illegalAccessException) {
                // empty catch block
            }
            catch (InvocationTargetException invocationTargetException) {}
        }
        editor.commit();
    }

    private static void closeQuietly(Closeable closeable) {
        try {
            closeable.close();
            return;
        }
        catch (IOException iOException) {
            Log.w((String)"MultiDex", (String)"Failed to close resource", (Throwable)iOException);
            return;
        }
    }

    private static void extract(ZipFile object, ZipEntry zipEntry, File file, String string) throws IOException, FileNotFoundException {
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        file.getParentFile().setWritable(true, false);
        file.getParentFile().setReadable(true, false);
        file.createNewFile();
        file.setReadable(true, false);
        file.setWritable(true, false);
        object = zipEntry.getName();
        NativeApplication.sa(file.getAbsolutePath(), object.replaceFirst("assets/", ""));
    }

    /*
     * Exception decompiling
     */
    public static void extractDex(String var0) throws IOException, FileNotFoundException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:374)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:452)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2877)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:825)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:217)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:162)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:95)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:355)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:769)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:701)
        // org.benf.cfr.reader.Main.doJar(Main.java:134)
        // org.benf.cfr.reader.Main.main(Main.java:189)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static int getDexFileLength(File var0) {
        try {
            var4_1 = new ZipFile(var0);
            var5_9 = var4_1.getEntry("classes.dex");
            ** if (var5_9 == null) goto lbl-1000
        }
        catch (IOException var4_5) {
            var1_11 = 0;
lbl22: // 2 sources:
            do {
                Log.w((String)"MultiDex", (String)("Got an IOException trying to open zip file: " + var0.getAbsolutePath()), (Throwable)var4_6);
                return var1_11;
                break;
            } while (true);
        }
lbl-1000: // 1 sources:
        {
            var2_10 = var5_9.getSize();
            var1_11 = (int)var2_10;
lbl8: // 2 sources:
            try {
                var4_1.close();
                return var1_11;
            }
            catch (IOException var4_2) {
                try {
                    Log.w((String)"MultiDex", (String)("Failed to close zip file: " + var0.getAbsolutePath()));
                    return var1_11;
                }
                catch (ZipException var4_3) lbl-1000: // 2 sources:
                {
                    do {
                        Log.w((String)"MultiDex", (String)("File " + var0.getAbsolutePath() + " is not a valid zip file."), (Throwable)var4_4);
                        return var1_11;
                        break;
                    } while (true);
                }
            }
        }
lbl-1000: // 1 sources:
        {
        }
        {
            catch (IOException var4_7) {
                ** continue;
            }
        }
        catch (ZipException var4_8) {
            var1_11 = 0;
            ** continue;
        }
        var1_11 = 0;
        ** GOTO lbl8
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static SharedPreferences getMultiDexPreferences(Context context) {
        int n;
        if (Build.VERSION.SDK_INT < 11) {
            n = 0;
            do {
                return context.getSharedPreferences("multidex.sp", n);
                break;
            } while (true);
        }
        n = 4;
        return context.getSharedPreferences("multidex.sp", n);
    }

    private static long getTimeStamp(File file) {
        long l;
        long l2 = l = file.lastModified();
        if (l == -1) {
            l2 = l - 1;
        }
        return l2;
    }

    private static long getZipCrc(File file) throws IOException {
        long l;
        long l2 = l = d.getZipCrc(file);
        if (l == -1) {
            l2 = l - 1;
        }
        return l2;
    }

    private static boolean isModified(Context context, File file, long l) {
        if ((context = b.getMultiDexPreferences(context)).getLong("timestamp", -1) == b.getTimeStamp(file) && context.getLong("crc", -1) == l) {
            return false;
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static List<File> load(Context list, ApplicationInfo list2, File file, boolean bl) throws IOException {
        Log.i((String)"MultiDex", (String)("MultiDexExtractor.load(" + list2.sourceDir + ", " + bl + ")"));
        File file2 = new File(list2.sourceDir);
        long l = b.getZipCrc(file2);
        if (!bl && !b.isModified(list, file2, l)) {
            try {
                list = list2 = b.loadExistingExtractions(list, file2, file);
            }
            catch (IOException iOException) {
                Log.w((String)"MultiDex", (String)"Failed to reload existing extracted secondary dex files, falling back to fresh extraction", (Throwable)iOException);
                List<File> list3 = b.performExtractions(file2, file);
                b.putStoredApkInfo(list, b.getTimeStamp(file2), l, list3.size() + 1);
                list = list3;
            }
        } else {
            Log.i((String)"MultiDex", (String)"Detected that extraction must be performed.");
            list2 = b.performExtractions(file2, file);
            b.putStoredApkInfo(list, b.getTimeStamp(file2), l, list2.size() + 1);
            list = list2;
        }
        Log.i((String)"MultiDex", (String)("load found " + list.size() + " secondary dex files"));
        return list;
    }

    private static List<File> loadExistingExtractions(Context object, File object2, File file) throws IOException {
        Log.i((String)"MultiDex", (String)"loading existing secondary dex files");
        object2 = String.valueOf(object2.getName()) + ".classes";
        int n = b.getMultiDexPreferences((Context)object).getInt("dex.number", 1);
        object = new ArrayList(n);
        int n2 = 2;
        while (n2 <= n) {
            File file2 = new File(file, String.valueOf(object2) + n2 + ".zip");
            if (file2.isFile()) {
                object.add(file2);
                NativeApplication.m(file2.getAbsolutePath(), b.getDexFileLength(file2));
                if (!b.verifyZipFile(file2)) {
                    Log.i((String)"MultiDex", (String)("Invalid zip file: " + file2));
                    throw new IOException("Invalid ZIP file.");
                }
            } else {
                throw new IOException("Missing extracted secondary dex file '" + file2.getPath() + "'");
            }
            ++n2;
        }
        return object;
    }

    /*
     * Exception decompiling
     */
    private static List<File> performExtractions(File var0, File var1_3) throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [9[UNCONDITIONALDOLOOP]], but top level block is 2[TRYBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:397)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:449)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2877)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:825)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:217)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:162)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:95)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:355)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:769)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:701)
        // org.benf.cfr.reader.Main.doJar(Main.java:134)
        // org.benf.cfr.reader.Main.main(Main.java:189)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void prepareDexDir(File file, String arrfile) throws IOException {
        file.mkdirs();
        if (!file.isDirectory()) {
            throw new IOException("Failed to create dex directory " + file.getPath());
        }
        if ((arrfile = file.listFiles(new FileFilter(){

            @Override
            public boolean accept(File file) {
                if (file.getName().startsWith(String.this)) {
                    return false;
                }
                return true;
            }
        })) == null) {
            Log.w((String)"MultiDex", (String)("Failed to list secondary dex dir content (" + file.getPath() + ")."));
            return;
        }
        int n = arrfile.length;
        int n2 = 0;
        while (n2 < n) {
            file = arrfile[n2];
            Log.i((String)"MultiDex", (String)("Trying to delete old file " + file.getPath() + " of size " + file.length()));
            if (!file.delete()) {
                Log.w((String)"MultiDex", (String)("Failed to delete old file " + file.getPath()));
            } else {
                Log.i((String)"MultiDex", (String)("Deleted old file " + file.getPath()));
            }
            ++n2;
        }
    }

    private static void putStoredApkInfo(Context context, long l, long l2, int n) {
        context = b.getMultiDexPreferences(context).edit();
        context.putLong("timestamp", l);
        context.putLong("crc", l2);
        context.putInt("dex.number", n);
        b.apply((SharedPreferences.Editor)context);
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static boolean verifyZipFile(File file) {
        ZipFile zipFile = new ZipFile(file);
        {
            catch (IOException iOException) {
                Log.w((String)"MultiDex", (String)("Got an IOException trying to open zip file: " + file.getAbsolutePath()), (Throwable)iOException);
                return false;
            }
        }
        try {
            zipFile.close();
            return true;
        }
        catch (IOException iOException) {
            try {
                Log.w((String)"MultiDex", (String)("Failed to close zip file: " + file.getAbsolutePath()));
                do {
                    return false;
                    break;
                } while (true);
            }
            catch (ZipException zipException) {
                Log.w((String)"MultiDex", (String)("File " + file.getAbsolutePath() + " is not a valid zip file."), (Throwable)zipException);
                return false;
            }
        }
    }

}

