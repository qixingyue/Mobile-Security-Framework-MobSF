/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 */
package com.shell;

import android.app.Application;
import android.content.Context;
import com.shell.NativeApplication;
import com.shell.a.a;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.zip.CRC32;
import java.util.zip.CheckedInputStream;
import java.util.zip.Checksum;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class SuperApplication
extends Application {
    static String baseDir = null;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void copyLib(ZipFile zipFile, ZipEntry object, File arrby) {
        try {
            byte[] arrby2;
            FileOutputStream fileOutputStream;
            if (!arrby2.getParentFile().exists()) {
                arrby2.getParentFile().mkdirs();
            }
            InputStream inputStream = zipFile.getInputStream((ZipEntry)((Object)fileOutputStream));
            fileOutputStream = new FileOutputStream((File)arrby2);
            arrby2 = new byte[1024];
            do {
                int n;
                if ((n = inputStream.read(arrby2)) == -1) {
                    inputStream.close();
                    fileOutputStream.close();
                    return;
                }
                fileOutputStream.write(arrby2, 0, n);
            } while (true);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static long getCRC32(File var0) {
        var1_7 = 0;
        var6_8 = null;
        var5_11 = null;
        if (!var0.exists()) {
            return var1_7;
        }
        var7_16 = new CRC32();
        var0 = new FileInputStream((File)var0);
        var5_11 = new CheckedInputStream((InputStream)var0, var7_16);
        var6_8 = new byte[1024];
        while (var5_11.read((byte[])var6_8) != -1) {
        }
        var3_18 = var7_16.getValue();
        ** if (var0 == null) goto lbl19
lbl-1000: // 1 sources:
        {
            var0.close();
        }
lbl19: // 2 sources:
        ** GOTO lbl27
        catch (Exception var0_2) {
            block27 : {
                var0 = null;
                ** GOTO lbl61
                catch (Throwable var5_12) {
                    block25 : {
                        var0 = null;
                        ** GOTO lbl39
                        catch (IOException var0_6) {}
lbl27: // 2 sources:
                        var1_7 = var3_18;
                        if (var5_11 == null) return var1_7;
                        try {
                            var5_11.close();
                            return var3_18;
                        }
                        catch (IOException var0_1) {
                            return var3_18;
                        }
                        catch (Throwable var5_14) {
                            break block25;
                        }
                        catch (Throwable var7_17) {
                            var6_8 = var5_11;
                            var5_11 = var7_17;
                        }
                    }
                    if (var0 != null) {
                        try {
                            var0.close();
                        }
                        catch (IOException var0_4) {}
                    }
                    if (var6_8 == null) throw var5_11;
                    try {
                        var6_8.close();
                    }
                    catch (IOException var0_5) {
                        throw var5_11;
                    }
                    throw var5_11;
                }
                catch (Exception var5_15) {
                    var6_8 = null;
                    var5_11 = var0;
                    var0 = var6_8;
                    break block27;
                }
                catch (Exception var6_9) {
                    var6_10 = var0;
                    var0 = var5_11;
                    var5_11 = var6_10;
                }
            }
            if (var5_11 == null) return var1_7;
            try {
                var5_11.close();
            }
            catch (IOException var5_13) {}
            if (var0 == null) return var1_7;
            try {
                var0.close();
                return 0;
            }
            catch (IOException var0_3) {
                return 0;
            }
        }
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        this.loadLibs(context);
        NativeApplication.load(this, "com.hundsun.stockwinner.hczq");
        a.init((Context)this);
        NativeApplication.run(this, "com.hundsun.winner.application.base.WinnerApplication");
    }

    protected void copyLib(String object) throws IOException {
        Object object2 = "assets/ijm_lib/armeabi/libexec.so";
        Object object3 = "assets/ijm_lib/armeabi/libexecmain.so";
        if (object.equals("x86")) {
            object2 = "assets/ijm_lib/x86/libexec.so";
            object3 = "assets/ijm_lib/x86/libexecmain.so";
        }
        File file = new File(baseDir, "libexec.so");
        object = new File(baseDir, "libexecmain.so");
        ZipFile zipFile = new ZipFile(this.getPackageCodePath());
        object2 = zipFile.getEntry((String)object2);
        if (object2 != null && object2.getCrc() != SuperApplication.getCRC32(file)) {
            this.copyLib(zipFile, (ZipEntry)object2, file);
        }
        if ((object3 = zipFile.getEntry((String)object3)) != null && object3.getCrc() != SuperApplication.getCRC32((File)object)) {
            this.copyLib(zipFile, (ZipEntry)object3, (File)object);
        }
        zipFile.close();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void loadLibs(Context object) {
        try {
            baseDir = object.getFilesDir().getAbsolutePath();
            object = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec("getprop ro.product.cpu.abi").getInputStream())).readLine();
            if (object != null && object.contains("x86")) {
                this.copyLib("x86");
                return;
            }
            this.copyLib("arm");
            return;
        }
        catch (IOException iOException) {
            try {
                this.copyLib("arm");
                return;
            }
            catch (IOException iOException2) {
                return;
            }
        }
    }

    public void onCreate() {
        NativeApplication.runAll(this, "com.hundsun.winner.application.base.WinnerApplication");
        super.onCreate();
    }
}

