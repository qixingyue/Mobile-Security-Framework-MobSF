/*
 * Decompiled with CFR 0_119.
 */
package com.shell.a;

import java.io.IOException;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;

class c {
    private static final long CENSIG = 33639248;
    private static final int GPBF_ENCRYPTED_FLAG = 1;
    private static final int GPBF_UNSUPPORTED_MASK = 1;
    static final Charset UTF_8 = Charset.forName("UTF-8");

    c() {
    }

    private static long getTime(int n, int n2) {
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        gregorianCalendar.set(14, 0);
        gregorianCalendar.set((n2 >> 9 & 127) + 1980, (n2 >> 5 & 15) - 1, n2 & 31, n >> 11 & 31, n >> 5 & 63, (n & 31) << 1);
        return gregorianCalendar.getTime().getTime();
    }

    static ZipEntry readEntry(ByteBuffer byteBuffer) throws IOException {
        byte[] arrby;
        if ((long)byteBuffer.getInt() != 33639248) {
            throw new ZipException("Central Directory Entry not found");
        }
        byteBuffer.position(8);
        int n = byteBuffer.getShort() & 65535;
        if ((n & 1) != 0) {
            throw new ZipException("Invalid General Purpose Bit Flag: " + n);
        }
        n = byteBuffer.getShort();
        short s = byteBuffer.getShort();
        short s2 = byteBuffer.getShort();
        long l = byteBuffer.getInt();
        long l2 = byteBuffer.getInt();
        long l3 = byteBuffer.getInt();
        short s3 = byteBuffer.getShort();
        int n2 = byteBuffer.getShort() & 65535;
        int n3 = byteBuffer.getShort() & 65535;
        byteBuffer.position(42);
        byteBuffer.getInt();
        Object object = new byte[s3 & 65535];
        byteBuffer.get((byte[])object, 0, object.length);
        object = new ZipEntry(new String((byte[])object, 0, object.length, UTF_8));
        object.setMethod(n & 65535);
        object.setTime(c.getTime(s & 65535, s2 & 65535));
        object.setCrc(l & 0xFFFFFFFFL);
        object.setCompressedSize(l2 & 0xFFFFFFFFL);
        object.setSize(l3 & 0xFFFFFFFFL);
        if (n3 > 0) {
            arrby = new byte[n3];
            byteBuffer.get(arrby, 0, n3);
            object.setComment(new String(arrby, 0, arrby.length, UTF_8));
        }
        if (n2 > 0) {
            arrby = new byte[n2];
            byteBuffer.get(arrby, 0, n2);
            object.setExtra(arrby);
        }
        return object;
    }
}

