/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 *  dalvik.system.DexFile
 */
package com.shell.a;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import com.shell.a.b;
import dalvik.system.DexFile;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipFile;

public final class a {
    private static final boolean IS_VM_MULTIDEX_CAPABLE = false;
    private static final int MAX_SUPPORTED_SDK_VERSION = 20;
    private static final int MIN_SDK_VERSION = 4;
    private static final String OLD_SECONDARY_FOLDER_NAME = "secondary-dexes";
    private static final String SECONDARY_FOLDER_NAME = "code_cache" + File.separator + "secondary-dexes";
    static final String TAG = "MultiDex";
    private static final int VM_WITH_MULTIDEX_VERSION_MAJOR = 2;
    private static final int VM_WITH_MULTIDEX_VERSION_MINOR = 1;
    private static final Set<String> installedApk = new HashSet<String>();

    private a() {
    }

    private static boolean checkValidZipFiles(List<File> object) {
        object = object.iterator();
        do {
            if (object.hasNext()) continue;
            return true;
        } while (b.verifyZipFile((File)object.next()));
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void clearOldDexDir(Context object) throws Exception {
        if (!(object = new File(object.getFilesDir(), "secondary-dexes")).isDirectory()) return;
        Log.i((String)"MultiDex", (String)("Clearing old secondary dex dir (" + object.getPath() + ")."));
        File[] arrfile = object.listFiles();
        if (arrfile == null) {
            Log.w((String)"MultiDex", (String)("Failed to list secondary dex dir content (" + object.getPath() + ")."));
            return;
        }
        int n = arrfile.length;
        int n2 = 0;
        do {
            if (n2 >= n) {
                if (object.delete()) break;
                Log.w((String)"MultiDex", (String)("Failed to delete secondary dex dir " + object.getPath()));
                return;
            }
            File file = arrfile[n2];
            Log.i((String)"MultiDex", (String)("Trying to delete old file " + file.getPath() + " of size " + file.length()));
            if (!file.delete()) {
                Log.w((String)"MultiDex", (String)("Failed to delete old file " + file.getPath()));
            } else {
                Log.i((String)"MultiDex", (String)("Deleted old file " + file.getPath()));
            }
            ++n2;
        } while (true);
        Log.i((String)"MultiDex", (String)("Deleted old secondary dex dir " + object.getPath()));
    }

    private static void expandFieldArray(Object object, String object2, Object[] arrobject) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        object2 = a.findField(object, (String)object2);
        Object[] arrobject2 = (Object[])object2.get(object);
        Object[] arrobject3 = (Object[])Array.newInstance(arrobject2.getClass().getComponentType(), arrobject2.length + arrobject.length);
        System.arraycopy(arrobject2, 0, arrobject3, 0, arrobject2.length);
        System.arraycopy(arrobject, 0, arrobject3, arrobject2.length, arrobject.length);
        object2.set(object, arrobject3);
    }

    private static Field findField(Object object, String string) throws NoSuchFieldException {
        Class class_ = object.getClass();
        do {
            if (class_ == null) {
                throw new NoSuchFieldException("Field " + string + " not found in " + object.getClass());
            }
            try {
                Field field = class_.getDeclaredField(string);
                if (!field.isAccessible()) {
                    field.setAccessible(true);
                }
                return field;
            }
            catch (NoSuchFieldException noSuchFieldException) {
                class_ = class_.getSuperclass();
                continue;
            }
            break;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static /* varargs */ Method findMethod(Object class_, String string, Class<?> ... arrclass) {
        class_ = class_.getClass();
        while (class_ != null) {
            Method method;
            Method method2;
            try {
                method = method2 = class_.getDeclaredMethod(string, arrclass);
            }
            catch (NoSuchMethodException noSuchMethodException) {
                class_ = class_.getSuperclass();
                continue;
            }
            if (method2.isAccessible()) return method;
            method2.setAccessible(true);
            return method2;
            break;
        }
        return null;
    }

    private static ApplicationInfo getApplicationInfo(Context object) throws PackageManager.NameNotFoundException {
        PackageManager packageManager;
        try {
            packageManager = object.getPackageManager();
            object = object.getPackageName();
            if (packageManager == null || object == null) {
                return null;
            }
        }
        catch (RuntimeException runtimeException) {
            Log.w((String)"MultiDex", (String)"Failure while trying to obtain ApplicationInfo from Context. Must be running in test mode. Skip patching.", (Throwable)runtimeException);
            return null;
        }
        return packageManager.getApplicationInfo((String)object, 128);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static void init(Context var0) {
        Log.i((String)"MultiDex", (String)"init");
        if (Build.VERSION.SDK_INT < 4) {
            throw new RuntimeException("Multi dex installation failed. SDK " + Build.VERSION.SDK_INT + " is unsupported. Min SDK version is " + 4 + ".");
        }
        try {
            var2_3 = a.getApplicationInfo(var0);
            if (var2_3 == null) {
                return;
            }
            var1_4 = a.installedApk;
            // MONITORENTER : var1_4
            var3_5 = var2_3.sourceDir;
            ** if (!a.installedApk.contains((Object)var3_5)) goto lbl-1000
        }
        catch (Exception var0_1) {
            Log.e((String)"MultiDex", (String)"Multidex installation failure", (Throwable)var0_1);
            throw new RuntimeException("Multi dex installation failed (" + var0_1.getMessage() + ").");
        }
lbl-1000: // 1 sources:
        {
            // MONITOREXIT : var1_4
            return;
        }
lbl-1000: // 1 sources:
        {
        }
        a.installedApk.add((String)var3_5);
        try {
            var3_5 = var0.getClassLoader();
            ** if (var3_5 != null) goto lbl-1000
        }
        catch (RuntimeException var0_2) {
            Log.w((String)"MultiDex", (String)"Failure while trying to obtain Context class loader. Must be running in test mode. Skip patching.", (Throwable)var0_2);
            // MONITOREXIT : var1_4
            return;
        }
lbl-1000: // 1 sources:
        {
            Log.e((String)"MultiDex", (String)"Context class loader is null. Must be running in test mode. Skip patching.");
            // MONITOREXIT : var1_4
            return;
        }
lbl-1000: // 1 sources:
        {
        }
        try {
            a.clearOldDexDir(var0);
        }
        catch (Throwable var4_6) {
            Log.w((String)"MultiDex", (String)"Something went wrong when trying to clear old MultiDex extraction, continuing without cleaning.", (Throwable)var4_6);
        }
        if (a.checkValidZipFiles(var5_8 = b.load(var0, var2_3, var4_7 = new File(var2_3.dataDir, a.SECONDARY_FOLDER_NAME), false))) {
            a.installSecondaryDexes((ClassLoader)var3_5, var4_7, var5_8);
        } else {
            Log.w((String)"MultiDex", (String)"Files were not valid zip files.  Forcing a reload.");
            var0 = b.load(var0, var2_3, var4_7, true);
            if (a.checkValidZipFiles(var0) == false) throw new RuntimeException("Zip files were not valid.");
            a.installSecondaryDexes((ClassLoader)var3_5, var4_7, var0);
        }
        // MONITOREXIT : var1_4
        Log.i((String)"MultiDex", (String)"install done");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void installSecondaryDexes(ClassLoader classLoader, File file, List<File> list) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException, IOException {
        if (list.isEmpty()) return;
        if (Build.VERSION.SDK_INT >= 19) {
            cc.install(classLoader, list, file);
            return;
        }
        if (Build.VERSION.SDK_INT >= 14) {
            bb.install(classLoader, list, file);
            return;
        }
        aa.install(classLoader, list);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    static boolean isVMMultidexCapable(String var0) {
        block7 : {
            block8 : {
                var3_2 = var4_1 = false;
                if (var0 != null) {
                    var5_3 = Pattern.compile("(\\d+)\\.(\\d+)(\\.\\d+)?").matcher(var0);
                    var3_2 = var4_1;
                    if (var5_3.matches()) {
                        var1_5 = Integer.parseInt(var5_3.group(1));
                        var2_6 = Integer.parseInt(var5_3.group(2));
                        if (var1_5 > 2) break block7;
                        var3_2 = var4_1;
                        if (var1_5 != 2) break block8;
                        if (var2_6 >= 1) break block7;
                        var3_2 = var4_1;
                    }
                }
            }
lbl15: // 3 sources:
            var5_3 = new StringBuilder("VM with version ").append(var0);
            if (var3_2) {
                var0 = " has multidex support";
lbl18: // 2 sources:
                do {
                    Log.i((String)"MultiDex", (String)var5_3.append(var0).toString());
                    return var3_2;
                    break;
                } while (true);
            }
            ** GOTO lbl25
        }
        var3_2 = true;
        ** GOTO lbl15
lbl25: // 1 sources:
        var0 = " does not have multidex support";
        ** while (true)
        catch (NumberFormatException var5_4) {
            var3_2 = var4_1;
            ** GOTO lbl15
        }
    }

    private static final class aa {
        private aa() {
        }

        private static void install(ClassLoader classLoader, List<File> object) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, IOException {
            int n = object.size();
            Field field = a.findField(classLoader, "path");
            StringBuilder stringBuilder = new StringBuilder((String)field.get(classLoader));
            Object[] arrobject = new String[n];
            Object[] arrobject2 = new File[n];
            Object[] arrobject3 = new ZipFile[n];
            Object[] arrobject4 = new DexFile[n];
            object = object.listIterator();
            do {
                if (!object.hasNext()) {
                    field.set(classLoader, stringBuilder.toString());
                    a.expandFieldArray(classLoader, "mPaths", arrobject);
                    a.expandFieldArray(classLoader, "mFiles", arrobject2);
                    a.expandFieldArray(classLoader, "mZips", arrobject3);
                    a.expandFieldArray(classLoader, "mDexs", arrobject4);
                    return;
                }
                File file = (File)object.next();
                String string = file.getAbsolutePath();
                stringBuilder.append(':').append(string);
                n = object.previousIndex();
                arrobject[n] = string;
                arrobject2[n] = file;
                arrobject3[n] = new ZipFile(file);
                arrobject4[n] = DexFile.loadDex((String)string, (String)(String.valueOf(string) + ".dex"), (int)0);
            } while (true);
        }
    }

    private static final class bb {
        private bb() {
        }

        private static void install(ClassLoader object, List<File> list, File file) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException {
            object = a.findField(object, "pathList").get(object);
            a.expandFieldArray(object, "dexElements", bb.makeDexElements(object, new ArrayList<File>(list), file));
        }

        private static Object[] makeDexElements(Object object, ArrayList<File> arrayList, File file) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
            return (Object[])a.findMethod(object, "makeDexElements", new Class[]{ArrayList.class, File.class}).invoke(object, arrayList, file);
        }
    }

    private static final class cc {
        private cc() {
        }

        /*
         * Enabled aggressive block sorting
         */
        private static void install(ClassLoader classLoader, List<File> arriOException, File object) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException {
            IOException[] arriOException2 = a.findField(classLoader, "pathList").get(classLoader);
            ArrayList<IOException> arrayList = new ArrayList<IOException>();
            a.expandFieldArray(arriOException2, "dexElements", cc.makeDexElements(arriOException2, new ArrayList<File>((Collection<File>)arriOException), (File)object, arrayList));
            if (arrayList.size() <= 0) return;
            {
                arriOException = arrayList.iterator();
                do {
                    if (!arriOException.hasNext()) {
                        object = a.findField(classLoader, "dexElementsSuppressedExceptions");
                        arriOException2 = (IOException[])object.get(classLoader);
                        if (arriOException2 == null) {
                            arriOException = arrayList.toArray(new IOException[arrayList.size()]);
                        } else {
                            arriOException = new IOException[arrayList.size() + arriOException2.length];
                            arrayList.toArray(arriOException);
                            System.arraycopy(arriOException2, 0, arriOException, arrayList.size(), arriOException2.length);
                        }
                        object.set(classLoader, arriOException);
                        return;
                    }
                    Log.w((String)"MultiDex", (String)"Exception in makeDexElement", (Throwable)((IOException)arriOException.next()));
                } while (true);
            }
        }

        private static Object[] makeDexElements(Object object, ArrayList<File> arrayList, File file, ArrayList<IOException> arrayList2) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
            Method method;
            Method method2 = method = a.findMethod(object, "makeDexElements", new Class[]{ArrayList.class, File.class, ArrayList.class});
            if (method == null) {
                method2 = a.findMethod(object, "makePathElements", new Class[]{List.class, File.class, List.class});
            }
            return (Object[])method2.invoke(object, arrayList, file, arrayList2);
        }
    }

}

