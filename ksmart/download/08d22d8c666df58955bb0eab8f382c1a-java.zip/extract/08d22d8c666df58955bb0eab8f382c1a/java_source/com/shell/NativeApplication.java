/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.Application
 */
package com.shell;

import android.app.Application;
import com.shell.SuperApplication;

public class NativeApplication {
    static {
        System.load(String.valueOf(SuperApplication.baseDir) + "/libexec.so");
        System.load(String.valueOf(SuperApplication.baseDir) + "/libexecmain.so");
    }

    public static native byte[] b2b(byte[] var0, int var1);

    public static native boolean load(Application var0, String var1);

    public static native void m(String var0, int var1);

    public static native boolean run(Application var0, String var1);

    public static native boolean runAll(Application var0, String var1);

    public static native void sa(String var0, String var1);
}

