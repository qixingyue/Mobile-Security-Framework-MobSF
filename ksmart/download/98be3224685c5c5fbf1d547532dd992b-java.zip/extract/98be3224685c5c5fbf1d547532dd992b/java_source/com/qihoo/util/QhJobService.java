/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.job.JobInfo
 *  android.app.job.JobInfo$Builder
 *  android.app.job.JobParameters
 *  android.app.job.JobScheduler
 *  android.app.job.JobService
 *  android.content.ComponentName
 *  android.content.Context
 */
package com.qihoo.util;

import android.annotation.TargetApi;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

@TargetApi(value=21)
public class QhJobService
extends JobService {
    static final int jobId = 1;

    public static native void interface10();

    public static void schedule(Context context) {
        JobScheduler jobScheduler = (JobScheduler)context.getSystemService("jobscheduler");
        Iterator<E> iterator = jobScheduler.getAllPendingJobs().iterator();
        while (iterator.hasNext()) {
            if (((JobInfo)iterator.next()).getId() != 1) continue;
            return;
        }
        jobScheduler.schedule(new JobInfo.Builder(1, new ComponentName(context.getPackageName(), QhJobService.class.getName())).setRequiresDeviceIdle(true).setRequiresCharging(true).setPeriodic(TimeUnit.DAYS.toMillis(1)).build());
    }

    public boolean onStartJob(final JobParameters jobParameters) {
        new Thread("DexOptJobService_DexOptimization"){

            @Override
            public void run() {
                QhJobService.interface10();
                QhJobService.this.jobFinished(jobParameters, false);
            }
        }.start();
        return true;
    }

    public boolean onStopJob(JobParameters jobParameters) {
        return false;
    }

}

