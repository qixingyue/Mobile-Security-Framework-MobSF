/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.location.Location
 *  android.location.LocationManager
 *  android.os.Build
 */
package com.qihoo.util;

import android.app.Application;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import com.qihoo.util.Configuration;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

public class StubApp2978734307
extends Application {
    private static Context context;
    private static boolean loadFromLib;
    public static Application newApp;
    public static Application runApp;
    private static String soName;
    public static String strEntryApplication;

    static {
        runApp = null;
        strEntryApplication = "com.qihoo360.crypt.entryRunApplication";
        newApp = null;
        soName = "libjiagu";
        loadFromLib = false;
    }

    public static void ChangeTopApplication() {
        Context context = runApp.getBaseContext();
        try {
            StubApp2978734307.interface7(newApp, context);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean copy(Context object, String object2, String object3, String string) {
        string = (String)object3 + "/" + string;
        if (!(object3 = new File((String)object3)).exists()) {
            object3.mkdir();
        }
        try {
            int n;
            Object object4 = new File(string);
            if (object4.exists()) {
                BufferedInputStream bufferedInputStream;
                object3 = object.getResources().getAssets().open((String)object2);
                BufferedInputStream bufferedInputStream2 = new BufferedInputStream((InputStream)object3);
                boolean bl = StubApp2978734307.isSameFile(bufferedInputStream2, bufferedInputStream = new BufferedInputStream((InputStream)(object4 = new FileInputStream((File)object4))));
                object3.close();
                object4.close();
                bufferedInputStream2.close();
                bufferedInputStream.close();
                if (bl) {
                    return bl;
                }
            }
            object = object.getResources().getAssets().open((String)object2);
            object2 = new FileOutputStream(string);
            object3 = new byte[7168];
            while ((n = object.read((byte[])object3)) > 0) {
                object2.write((byte[])object3, 0, n);
            }
            object2.close();
            object.close();
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return false;
        }
        try {
            Runtime.getRuntime().exec("chmod 755 " + string);
            return true;
        }
        catch (Exception exception) {
            return true;
        }
    }

    public static Context getAppContext() {
        return context;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Application getNewAppInstance(Context class_) {
        block5 : {
            try {
                if (newApp != null || (class_ = class_.getClassLoader()) == null) break block5;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return newApp;
            }
            class_ = class_.loadClass(strEntryApplication);
            if (class_ == null) break block5;
            newApp = (Application)class_.newInstance();
        }
        do {
            return newApp;
            break;
        } while (true);
    }

    private void initAssetForNative() {
        try {
            Class.forName("com.qihoo.dexjiagu.TransitMgr").getMethod("initAssetForNative", Context.class).invoke(null, new Object[]{this});
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    private void initCrashReport() {
        try {
            Class.forName("com.qihoo.bugreport.CrashReport").getDeclaredMethod("init", Context.class).invoke(null, new Object[]{this.getApplicationContext()});
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    public static native void interface10(Context var0);

    public static native void interface5(Application var0);

    public static native String interface6(String var0);

    public static native boolean interface7(Application var0, Context var1);

    public static native boolean interface8(Application var0, Context var1);

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean isSameFile(BufferedInputStream bufferedInputStream, BufferedInputStream bufferedInputStream2) {
        byte[] arrby;
        byte[] arrby2;
        int n = bufferedInputStream.available();
        int n2 = bufferedInputStream2.available();
        if (n != n2) return false;
        try {
            arrby2 = new byte[n];
            arrby = new byte[n2];
            bufferedInputStream.read(arrby2);
            bufferedInputStream2.read(arrby);
            n2 = 0;
        }
        catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
            return false;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return false;
        }
        while (n2 < n) {
            byte by = arrby2[n2];
            byte by2 = arrby[n2];
            if (by != by2) {
                return false;
            }
            ++n2;
        }
        return true;
    }

    /*
     * Exception decompiling
     */
    public static Boolean isX86Arch() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 24[WHILELOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:397)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:449)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2877)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:825)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:217)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:162)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:95)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:355)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:769)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:701)
        // org.benf.cfr.reader.Main.doJar(Main.java:134)
        // org.benf.cfr.reader.Main.main(Main.java:189)
        throw new IllegalStateException("Decompilation failed");
    }

    public static native Location mark(LocationManager var0, String var1);

    public static native void mark();

    public static native void mark(Location var0);

    public static native int n01111(int var0);

    public static native int n011111(int var0, int var1);

    public static native int n0111111(int var0, int var1, int var2);

    public static native int n01111111(int var0, int var1, int var2, int var3);

    public static native int n011111111(int var0, int var1, int var2, int var3, int var4);

    public static native int n011111111131(int var0, int var1, int var2, int var3, int var4, int var5, int var6, Object var7);

    public static native Object n0111113(int var0, int var1, int var2);

    public static native int n01111131(int var0, int var1, int var2, Object var3);

    public static native long n01112(int var0);

    public static native Object n01113(int var0);

    public static native int n011131(int var0, Object var1);

    public static native long n0112();

    public static native void n01120(long var0);

    public static native byte n01121(long var0);

    public static native Object n011213(long var0, int var2);

    public static native void n0112210(long var0, long var2, int var4);

    public static native Object n01122113(double var0, double var2, int var4, int var5);

    public static native void n01123110(long var0, Object var2, int var3, int var4);

    public static native Object n0113();

    public static native void n01130(Object var0);

    public static native int n0113111(Object var0, int var1, int var2);

    public static native Object n011313(Object var0, int var1);

    public static native void n011313110(Object var0, int var1, Object var2, int var3, int var4);

    public static native Object n01133(Object var0);

    public static native void n011331110(Object var0, Object var1, int var2, int var3, int var4);

    public static native int n01133331(Object var0, Object var1, Object var2, Object var3);

    private void prepareInitCrashReport() {
        try {
            Class.forName("com.qihoo.bugreport.CrashReport").getDeclaredMethod("prepareInit", new Class[0]).invoke(null, new Object[0]);
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void attachBaseContext(Context context) {
        Object object;
        super.attachBaseContext(context);
        StubApp2978734307.context = context;
        if (runApp == null) {
            runApp = this;
        }
        if (newApp == null) {
            object = context.getFilesDir().getParentFile().getAbsolutePath();
            String string = (String)object + "/.jiagu";
            Boolean bl = StubApp2978734307.isX86Arch();
            object = false;
            Boolean bl2 = false;
            if (Build.CPU_ABI.contains("64") || Build.CPU_ABI2.contains("64")) {
                object = true;
            }
            if (Build.CPU_ABI.contains("mips") || Build.CPU_ABI2.contains("mips")) {
                bl2 = true;
            }
            if (bl2.booleanValue()) {
                StubApp2978734307.copy(context, soName + "_mips.so", string, soName + ".so");
            } else if (bl.booleanValue()) {
                StubApp2978734307.copy(context, soName + "_x86.so", string, soName + ".so");
            } else {
                StubApp2978734307.copy(context, soName + ".so", string, soName + ".so");
            }
            if (loadFromLib) {
                System.loadLibrary("jiagu");
            } else if (object.booleanValue() && !bl2.booleanValue()) {
                if (bl.booleanValue()) {
                    StubApp2978734307.copy(context, soName + "_x64.so", string, soName + "_64.so");
                } else {
                    StubApp2978734307.copy(context, soName + "_a64.so", string, soName + "_64.so");
                }
                System.load(string + "/" + soName + "_64.so");
            } else {
                System.load(string + "/" + soName + ".so");
            }
        }
        StubApp2978734307.interface5(runApp);
        newApp = StubApp2978734307.getNewAppInstance(context);
        if (newApp != null) {
            try {
                object = Application.class.getDeclaredMethod("attach", Context.class);
                if (object != null) {
                    object.setAccessible(true);
                    object.invoke((Object)newApp, new Object[]{context});
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            StubApp2978734307.interface8(newApp, context);
        } else {
            System.exit(1);
        }
        this.initAssetForNative();
    }

    public synchronized native void n1000();

    public synchronized native int n1001();

    public synchronized native Object n100111111133(int var1, int var2, int var3, int var4, int var5, boolean var6, boolean var7, Object var8);

    public synchronized native int n100131(int var1, Object var2);

    public synchronized native int n1003131(Object var1, int var2, Object var3);

    public native void n1110();

    public native int n1111();

    public native int n11111(int var1);

    public native int n111111(int var1, int var2);

    public native int n1111111(int var1, int var2, int var3);

    public native int n11111111(int var1, int var2, int var3, int var4);

    public native int n1111111131(int var1, int var2, int var3, int var4, int var5, Object var6);

    public native int n111111131(int var1, int var2, int var3, int var4, Object var5);

    public native int n11111131(int var1, int var2, int var3, Object var4);

    public native Object n111113(int var1, int var2);

    public native void n1111130(int var1, int var2, Object var3);

    public native int n1111131(int var1, int var2, Object var3);

    public native Object n11113(int var1);

    public native int n111131(int var1, Object var2);

    public native int n1111311(int var1, Object var2, int var3);

    public native int n1111311111(int var1, Object var2, int var3, int var4, int var5, int var6);

    public native int n11113111131(int var1, Object var2, int var3, int var4, int var5, int var6, Object var7);

    public native int n1111311131(int var1, Object var2, int var3, int var4, int var5, Object var6);

    public native Object n1111313(int var1, Object var2, int var3);

    public native Object n1113();

    public native void n11130(Object var1);

    public native int n11131(Object var1);

    public native int n111311(Object var1, int var2);

    public native int n111313111(Object var1, int var2, Object var3, int var4, int var5);

    public native int n11131331331(Object var1, int var2, Object var3, Object var4, int var5, Object var6, Object var7);

    public native int n111331(Object var1, Object var2);

    public void onCreate() {
        super.onCreate();
        if (Configuration.ENABLE_CRASH_REPORT) {
            this.prepareInitCrashReport();
        }
        StubApp2978734307.ChangeTopApplication();
        if (newApp != null) {
            newApp.onCreate();
        }
        if (Configuration.ENABLE_CRASH_REPORT) {
            this.initCrashReport();
        }
        StubApp2978734307.interface10(StubApp2978734307.getAppContext());
    }
}

