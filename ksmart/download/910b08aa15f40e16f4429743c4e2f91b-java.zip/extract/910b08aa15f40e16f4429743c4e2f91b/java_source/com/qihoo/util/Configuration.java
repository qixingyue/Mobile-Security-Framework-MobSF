/*
 * Decompiled with CFR 0_119.
 */
package com.qihoo.util;

public class Configuration {
    public static boolean ENABLE_CRASH_REPORT = true;
}

