/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Looper
 *  android.view.Window
 */
package com.qihoo.util;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Looper;
import android.view.Window;

public class QHDialog {
    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void showDialog(Context object, String string) {
        object = new Thread(new Runnable((Context)object, string){
            final /* synthetic */ Context val$context;
            final /* synthetic */ String val$msg;

            @Override
            public void run() {
                Looper.prepare();
                AlertDialog alertDialog = new AlertDialog.Builder(this.val$context).setMessage((CharSequence)this.val$msg).setCancelable(false).setPositiveButton((CharSequence)"\u786e\u5b9a", new DialogInterface.OnClickListener(){

                    /*
                     * Enabled aggressive block sorting
                     * Enabled unnecessary exception pruning
                     * Enabled aggressive exception aggregation
                     */
                    public void onClick(DialogInterface object, int n) {
                        object = Thread.currentThread();
                        synchronized (object) {
                            if (Build.VERSION.SDK_INT >= 19) {
                                object.notify();
                            }
                            return;
                        }
                    }
                }).create();
                alertDialog.getWindow().setType(2005);
                alertDialog.show();
                Looper.loop();
            }

        });
        synchronized (object) {
            block5 : {
                try {
                    object.start();
                    if (Build.VERSION.SDK_INT >= 19) {
                        object.wait();
                        break block5;
                    }
                    Thread.sleep(3000);
                }
                catch (InterruptedException interruptedException) {}
            }
            return;
        }
    }

}

